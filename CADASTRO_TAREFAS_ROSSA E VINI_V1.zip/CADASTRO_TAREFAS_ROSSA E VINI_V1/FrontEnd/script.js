class Tarefa {
  #status;

  constructor(titulo, descricao, responsavel, status = "Pendente") {
    if (!titulo || !descricao || !responsavel) throw new Error("Por favor, preencha todos os campos");
    this.titulo = titulo;
    this.descricao = descricao;
    this.responsavel = responsavel;
    this.#status = status;
  }

  get status() { return this.#status; }

  alterarStatus() {
    const estados = ["Pendente", "Em Andamento", "Concluída"];
    this.#status = estados[(estados.indexOf(this.#status) + 1) % estados.length];
  }
  
  atualizarDados(titulo, descricao, responsavel) {
    this.titulo = titulo;
    this.descricao = descricao;
    this.responsavel = responsavel;
  }
}

const DB_KEY = 'tarefas_rossa_vini';
let tarefas = JSON.parse(localStorage.getItem(DB_KEY)) || [];
let editandoIndex = null;

document.addEventListener('DOMContentLoaded', () => {
  tarefas = tarefas.map(tarefa => {
      if (!tarefa.status) {
          return {...tarefa, status: "Pendente"};
      }
      return tarefa;
  });
  salvarNoBanco();
  atualizarTabela();
});

document.getElementById("tarefa-form").addEventListener("submit", function(e) {
  e.preventDefault();
  try {
      const titulo = document.getElementById("titulo").value;
      const descricao = document.getElementById("descricao").value;
      const responsavel = document.getElementById("responsavel").value;
      
      if (editandoIndex !== null) {
          // Editar tarefa existente
          tarefas[editandoIndex].atualizarDados(titulo, descricao, responsavel);
          editandoIndex = null;
          document.querySelector("#tarefa-form button").textContent = "Adicionar Tarefa";
      } else {
          // Adicionar nova tarefa
          const novaTarefa = new Tarefa(titulo, descricao, responsavel);
          tarefas.push(novaTarefa);
      }
      
      salvarNoBanco();
      atualizarTabela();
      e.target.reset();
  } catch (erro) {
      alert(erro.message);
  }
});

function atualizarTabela() {
  const tbody = document.querySelector("#tabela-tarefas tbody");
  tbody.innerHTML = "";
  tarefas.forEach((tarefa, index) => {
      const row = document.createElement("tr");
      row.innerHTML = `
          <td>${tarefa.titulo}</td>
          <td>${tarefa.responsavel}</td>
          <td>${tarefa.status || "Pendente"}</td>
          <td class="actions">
              <button onclick="editarTarefa(${index})">Editar</button>
              <button onclick="alterarStatus(${index})">Status</button>
              <button onclick="removerTarefa(${index})">Remover</button>
          </td>
      `;
      tbody.appendChild(row);
  });
  atualizarResumo();
}

function editarTarefa(index) {
  const tarefa = tarefas[index];
  document.getElementById("titulo").value = tarefa.titulo;
  document.getElementById("descricao").value = tarefa.descricao;
  document.getElementById("responsavel").value = tarefa.responsavel;
  
  editandoIndex = index;
  document.querySelector("#tarefa-form button").textContent = "Salvar Edição";
  document.getElementById("titulo").focus();
}

function alterarStatus(index) {
  tarefas[index].alterarStatus();
  salvarNoBanco();
  atualizarTabela();
}

function removerTarefa(index) {
  if (confirm("Tem certeza que deseja remover esta tarefa?")) {
      tarefas.splice(index, 1);
      salvarNoBanco();
      atualizarTabela();
  }
}

function atualizarResumo() {
  const contagem = { "Pendente": 0, "Em Andamento": 0, "Concluída": 0 };
  tarefas.forEach(t => {
      const status = t.status || "Pendente";
      contagem[status]++;
  });
  document.getElementById("resumo-status").textContent = 
      `Pendente: ${contagem["Pendente"]} | Em Andamento: ${contagem["Em Andamento"]} | Concluída: ${contagem["Concluída"]}`;
}

function salvarNoBanco() {
  localStorage.setItem(DB_KEY, JSON.stringify(tarefas));
}